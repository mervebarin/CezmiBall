package view;

public interface AnimationWindow {

	void setEditmode(boolean b);

	void setMode(boolean b);

	void XmlWriter();

	void activateEditMode();

	void removeAll();

	void repaint();

}
